
class DataRW:
    def __init__(self, options):
        pass